.. Copyright © 2019–2024 Advanced Micro Devices, Inc

.. `Terms and Conditions <https://www.amd.com/en/corporate/copyright>`_.

.. meta::
   :keywords: Vitis, Library, Data Compression, AMD, L2 Kernels, Overview    
   :description: This section provides various application demos

===============
L2 Kernel Demos
===============

The L2 section uses the data compression algorithm which internally uses the optimized hardware modules to showcase various kernel demos.
